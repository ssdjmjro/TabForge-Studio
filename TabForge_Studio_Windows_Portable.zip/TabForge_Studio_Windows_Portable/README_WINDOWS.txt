========================================================================
       TabForge Studio - Stratocaster Guitar Studio (Windows Portable)
========================================================================

Welcome to TabForge Studio Portable for Windows (10 & 11)!

This portable edition requires ZERO installations, ZERO administrative rights,
and NO Python/MSYS2 dependencies. It runs directly on any Windows PC in any modern browser (Edge, Chrome, Firefox, Brave).

------------------------------------------------------------------------
HOW TO LAUNCH (1-CLICK)
------------------------------------------------------------------------
1. Extract "TabForge_Studio_Windows_Portable.zip" (if zipped).
2. Double-click "Start_TabForge_Studio.bat" (or double-click "index.html").
3. TabForge Studio will open instantly in your default web browser!

------------------------------------------------------------------------
FEATURES & CAPABILITIES
------------------------------------------------------------------------
- Interactive 22-Fret Fender Stratocaster Guitar Neck with Mother-of-Pearl Inlays.
- Web Audio Synthesizer (Realistic Guitar Pluck Sounds & Technique Audio).
- Songsterr-style Tab Staff Canvas & Real-time Animated Sweep Playback.
- Complete .ZIP Archive Support:
  * Import .zip archives containing tabs or HTML files.
  * One-Click Backup Archiver: Exports complete timestamped .zip backups of your app & tabs.
- Native .HTML File Support:
  * Open and load saved .html tab files directly in the app.
  * Save / Export standalone interactive .html tab files that can be opened anywhere.
- Save & Open native .JSON tab files (compatible with TabForge GTK).
- Export ASCII Tab text files (.txt) & Printable PDF sheet music output.
- Full technique suite: Natural Harmonics <NH>, Pinch Harmonics [AH], Dead Notes (X),
  Palm Mutes (PM), Bends (1/2, Full, 1.5, 2), Slides (/ and \), Vibrato (~), Hammer-on (h), Pull-off (p).
- 8 Guitar Tunings (Standard E, Drop D, Half-Step Down, Full-Step Down, Drop C, Open G, Open D, DADGAD) & Capo support (0-12).

========================================================================
TabForge Studio - Zero-Dependency Windows Edition
========================================================================
