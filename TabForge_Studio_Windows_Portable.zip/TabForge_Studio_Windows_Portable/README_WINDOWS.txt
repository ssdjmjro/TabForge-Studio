========================================================================
       TabForge Studio - Stratocaster Guitar Studio (Windows Portable)
========================================================================

Welcome to TabForge Studio Portable for Windows (10 & 11)!

This portable edition requires ZERO installations, ZERO administrative rights,
and NO Python/MSYS2 dependencies. It runs directly on any Windows PC.

------------------------------------------------------------------------
HOW TO LAUNCH (1-CLICK)
------------------------------------------------------------------------
1. Extract "TabForge_Studio_Windows_Portable.zip".
2. Double-click "Start_TabForge_Studio.bat" (or double-click "index.html").
3. TabForge Studio will open instantly in Microsoft Edge or Chrome!

------------------------------------------------------------------------
FEATURES
------------------------------------------------------------------------
- Interactive 22-Fret Fender Stratocaster Guitar Neck.
- Real-time Audio Synthesizer (Realistic Guitar Pluck Sounds).
- Songsterr-style Tab Staff Canvas & Real-time Sweep Playback.
- Save / Load Tab Files (.json).
- Export ASCII Tab files & PDF Print output.
- Support for Natural Harmonics <NH>, Pinch Harmonics [AH], Dead Notes (X),
  Palm Mutes (PM), Bends, Slides, and Vibrato.

========================================================================
TabForge Studio - Zero-Dependency Windows Edition
========================================================================
