@echo off
title TabForge Studio - Windows Portable Edition
color 0A
echo ===================================================================
echo      TabForge Studio - Stratocaster Guitar Studio (Windows Portable)
echo ===================================================================
echo.
echo Launching TabForge Studio in your default Web Browser...
echo.

:: Open index.html in Microsoft Edge, Chrome, or Default Browser
start "" "%~dp0index.html"

echo TabForge Studio is now running!
echo You can keep this window open or close it.
echo.
timeout /t 3 >nul
exit
