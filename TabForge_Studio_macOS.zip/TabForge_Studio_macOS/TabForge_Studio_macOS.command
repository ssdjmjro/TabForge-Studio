#!/usr/bin/env bash
# TabForge Studio - macOS Launcher
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$DIR"

# Include Homebrew paths (Apple Silicon & Intel Macs)
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"

if ! python3 -c "import gi; gi.require_version('Gtk', '4.0')" 2>/dev/null; then
    echo "[!] GTK4 or PyGObject bindings are missing."
    echo "Running automated Homebrew dependency installer..."
    bash setup_mac.sh
fi

python3 main.py "$@"
