#!/usr/bin/env bash
# TabForge Studio - macOS App Bundle Builder (PyInstaller)
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$DIR"

export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"

echo "==================================================================="
echo "  TabForge Studio - macOS .app Bundle Builder"
echo "==================================================================="
echo

if ! command -v pyinstaller &>/dev/null; then
    echo "[+] Installing PyInstaller..."
    pip3 install pyinstaller
fi

echo "[+] Building TabForgeStudio.app bundle..."
pyinstaller --noconfirm \
  --windowed \
  --name "TabForgeStudio" \
  --add-data "style.css:." \
  --add-data "stratocaster.svg:." \
  --hidden-import gi \
  --hidden-import gi.repository.Gtk \
  --hidden-import gi.repository.Adw \
  --hidden-import gi.repository.Gdk \
  --hidden-import gi.repository.Gio \
  --hidden-import gi.repository.GLib \
  --hidden-import gi.repository.GObject \
  --hidden-import gi.repository.Gst \
  --hidden-import cairo \
  main.py

echo
echo "[✔] macOS Build Complete! Bundle located at: dist/TabForgeStudio.app"
