========================================================================
       TabForge Studio - Stratocaster Guitar Studio (macOS Release)
========================================================================

Welcome to TabForge Studio for macOS (Intel & Apple Silicon M1/M2/M3/M4)!

------------------------------------------------------------------------
1. QUICK START
------------------------------------------------------------------------
Double-click `TabForge_Studio_macOS.command` in Finder to launch the app.

Alternatively, open Terminal in this folder and run:
   ./TabForge_Studio_macOS.command

------------------------------------------------------------------------
2. FIRST-TIME SETUP (DEPENDENCIES)
------------------------------------------------------------------------
If running for the first time on macOS:
   ./setup_mac.sh

This automatically installs GTK4, Libadwaita, PyGObject, GStreamer, and Cairo
via Homebrew.

------------------------------------------------------------------------
3. BUILDING A STANDALONE macOS .app BUNDLE
------------------------------------------------------------------------
To package TabForge Studio into a native macOS application (`TabForgeStudio.app`):
   ./build_mac_app.sh

The compiled `.app` will be saved in `dist/TabForgeStudio.app`.

------------------------------------------------------------------------
Created for TabForge Studio - macOS Release Package
========================================================================
