#!/usr/bin/env bash
# TabForge Studio - macOS Homebrew Dependency Installer
echo "==================================================================="
echo "  TabForge Studio - macOS Dependency Installer (Homebrew)"
echo "==================================================================="
echo

# Export PATH for Apple Silicon (/opt/homebrew) & Intel (/usr/local)
export PATH="/opt/homebrew/bin:/usr/local/bin:$PATH"

if ! command -v brew &>/dev/null; then
    echo "[!] Homebrew not detected. Installing official Homebrew package manager..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
fi

echo "[+] Installing GTK4, Libadwaita, PyGObject, GStreamer, Cairo & Python 3..."
brew install python3 gtk4 libadwaita pygobject3 gstreamer gst-plugins-good cairo

echo
echo "[✔] All macOS dependencies successfully installed!"
