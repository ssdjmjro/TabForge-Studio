#!/usr/bin/env bash
# TabForge Studio - Linux Desktop Shortcut Installer
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DESKTOP_DIR="$HOME/.local/share/applications"
mkdir -p "$DESKTOP_DIR"

CAT_FILE="$DESKTOP_DIR/io.github.tabforge.studio.desktop"

cat << EOF > "$CAT_FILE"
[Desktop Entry]
Name=TabForge Studio
Comment=Stratocaster Guitar Studio & Tab Writer
Exec=bash "$SCRIPT_DIR/TabForge_Studio.sh"
Icon=$SCRIPT_DIR/stratocaster.svg
Terminal=false
Type=Application
Categories=AudioVideo;Audio;Music;
EOF

chmod +x "$CAT_FILE"
echo "[✔] Application menu shortcut created at: $CAT_FILE"

if [ -d "$HOME/Desktop" ]; then
    cp "$CAT_FILE" "$HOME/Desktop/"
    chmod +x "$HOME/Desktop/io.github.tabforge.studio.desktop"
    echo "[✔] Desktop shortcut created!"
fi
