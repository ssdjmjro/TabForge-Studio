#!/usr/bin/env bash
# TabForge Studio - Linux Dependency Installer
echo "==================================================================="
echo "  TabForge Studio - Linux Dependency Installer"
echo "==================================================================="
echo

if command -v apt-get &>/dev/null; then
    echo "[+] Detected Debian/Ubuntu system..."
    sudo apt-get update
    sudo apt-get install -y python3 python3-gi gir1.2-gtk-4.0 gir1.2-adw-1 gir1.2-gst-plugins-base-1.0 gstreamer1.0-plugins-good python3-cairo
elif command -v dnf &>/dev/null; then
    echo "[+] Detected Fedora/RHEL system..."
    sudo dnf install -y python3 python3-gobject gtk4 libadwaita gstreamer1-plugins-good python3-cairo
elif command -v pacman &>/dev/null; then
    echo "[+] Detected Arch Linux system..."
    sudo pacman -S --needed python python-gobject gtk4 libadwaita gstreamer gst-plugins-good python-cairo
else
    echo "[!] Package manager not recognized automatically. Please install python3-gi, gtk4, libadwaita, gstreamer, and python-cairo manually."
fi

echo
echo "[✔] Dependencies setup complete!"
