#!/usr/bin/env bash
# TabForge Studio - Linux Launcher
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

if ! python3 -c "import gi; gi.require_version('Gtk', '4.0')" 2>/dev/null; then
    echo "[!] GTK4 or PyGObject bindings missing."
    echo "Running automated dependency installer..."
    bash setup_linux.sh
fi

python3 main.py "$@"
