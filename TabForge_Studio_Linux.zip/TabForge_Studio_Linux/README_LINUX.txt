========================================================================
       TabForge Studio - Stratocaster Guitar Studio (Linux Release)
========================================================================

Welcome to TabForge Studio for Linux!

------------------------------------------------------------------------
1. QUICK START
------------------------------------------------------------------------
To launch TabForge Studio, open a terminal in this directory and run:
   ./TabForge_Studio.sh

Or double-click `TabForge_Studio.sh` in your file manager.

------------------------------------------------------------------------
2. INSTALL DEPENDENCIES (IF NEEDED)
------------------------------------------------------------------------
If running for the first time or missing GTK4 / PyGObject dependencies:
   ./setup_linux.sh

This supports Ubuntu, Debian, Fedora, RHEL, Arch Linux, and derivatives.

------------------------------------------------------------------------
3. CREATE DESKTOP SHORTCUT
------------------------------------------------------------------------
To integrate TabForge Studio into your Linux application menu & Desktop:
   ./install_desktop_shortcut.sh

------------------------------------------------------------------------
Created for TabForge Studio - Linux Package
========================================================================
