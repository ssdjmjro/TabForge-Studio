@echo off
title TabForge Studio - Stratocaster Guitar Studio (Win64)
color 0A
echo ===================================================================
echo     TabForge Studio - Stratocaster Guitar Studio (Windows 64-bit)
echo ===================================================================
echo.

:: 1. Try MSYS2 UCRT64 Python Environment
if exist "C:\msys64\ucrt64.exe" (
    echo Launching via MSYS2 UCRT64 environment...
    C:\msys64\ucrt64.exe /bin/bash -lc "cd \"$(cygpath '%~dp0')\" && python3 main.py"
    goto END
)

:: 2. Try MSYS2 MINGW64 Python Environment
if exist "C:\msys64\mingw64.exe" (
    echo Launching via MSYS2 MINGW64 environment...
    C:\msys64\mingw64.exe /bin/bash -lc "cd \"$(cygpath '%~dp0')\" && python3 main.py"
    goto END
)

:: 3. Try Standard Windows 64-bit Python
python main.py
if %ERRORLEVEL% EQU 0 goto END

echo.
echo [!] Unable to start TabForge Studio directly.
echo [!] GTK4 or PyGObject bindings are missing in your Python environment.
echo.
echo Press any key to run automated Setup & Installer...
pause >nul
call Setup_Windows_x64.bat

:END
