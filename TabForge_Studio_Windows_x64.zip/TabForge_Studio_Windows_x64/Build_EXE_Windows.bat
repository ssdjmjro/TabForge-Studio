@echo off
title TabForge Studio - PyInstaller Standalone EXE Builder (Win64)
color 0C
echo ===================================================================
echo   TabForge Studio - PyInstaller Standalone EXE Builder (Win64)
echo ===================================================================
echo.
echo Building standalone executable TabForgeStudio.exe...
echo.

if exist "C:\msys64\ucrt64.exe" (
    echo Building inside MSYS2 UCRT64...
    C:\msys64\ucrt64.exe /bin/bash -lc "cd \"$(cygpath '%~dp0')\" && pacman -S --noconfirm --needed mingw-w64-ucrt-x86_64-python-pyinstaller && pyinstaller --noconfirm tabforge_studio.spec"
    echo.
    echo ===================================================================
    echo   Standalone Build Complete!
    echo   Executable located at: dist\TabForgeStudio_Win64\TabForgeStudio.exe
    echo ===================================================================
    echo.
    pause
    goto END
)

pyinstaller --noconfirm tabforge_studio.spec
echo.
echo ===================================================================
echo   Standalone Build Complete!
echo   Executable located at: dist\TabForgeStudio_Win64\TabForgeStudio.exe
echo ===================================================================
echo.
pause

:END
