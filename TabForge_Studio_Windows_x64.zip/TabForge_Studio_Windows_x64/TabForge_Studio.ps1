# TabForge Studio - PowerShell Launcher for Windows 64-bit
Write-Host "===================================================================" -ForegroundColor Cyan
Write-Host "    TabForge Studio - Stratocaster Guitar Studio (Win64)" -ForegroundColor Green
Write-Host "===================================================================" -ForegroundColor Cyan
Write-Host ""

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Check MSYS2
if (Test-Path "C:\msys64\ucrt64.exe") {
    Write-Host "Launching via MSYS2 UCRT64..." -ForegroundColor Yellow
    Start-Process "C:\msys64\ucrt64.exe" -ArgumentList "/bin/bash -lc `"cd '$ScriptDir' && python3 main.py`"" -Wait
    exit
}

if (Test-Path "C:\msys64\mingw64.exe") {
    Write-Host "Launching via MSYS2 MINGW64..." -ForegroundColor Yellow
    Start-Process "C:\msys64\mingw64.exe" -ArgumentList "/bin/bash -lc `"cd '$ScriptDir' && python3 main.py`"" -Wait
    exit
}

# Run via System Python
Set-Location $ScriptDir
python main.py
if ($LASTEXITCODE -ne 0) {
    Write-Host "[!] GTK4 / PyGObject dependencies missing." -ForegroundColor Red
    Write-Host "Running automated setup..." -ForegroundColor Yellow
    & "$ScriptDir\Setup_Windows_x64.bat"
}
