Set WshShell = CreateObject("WScript.Shell")
WshShell.Run "cmd /c TabForge_Studio.bat", 0, False
