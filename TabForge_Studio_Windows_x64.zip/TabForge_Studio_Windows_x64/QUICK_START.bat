@echo off
title TabForge Studio - Control Center (Win64)
:MENU
cls
color 0B
echo ===================================================================
echo     TabForge Studio - Stratocaster Guitar Studio (Win64)
echo ===================================================================
echo.
echo   [1] Run TabForge Studio
echo   [2] Run 1-Click Dependency Installer (Setup MSYS2 & GTK4)
echo   [3] Build Standalone Windows EXE (PyInstaller)
echo   [4] Create Desktop Shortcut
echo   [5] Exit
echo.
set /p choice="Select an option [1-5]: "

if "%choice%"=="1" (
    call TabForge_Studio.bat
    goto MENU
)
if "%choice%"=="2" (
    call Setup_Windows_x64.bat
    goto MENU
)
if "%choice%"=="3" (
    call Build_EXE_Windows.bat
    goto MENU
)
if "%choice%"=="4" (
    powershell -Command "$s=(New-Object -COM WScript.Shell).CreateShortcut([System.IO.Path]::Combine([Environment]::GetFolderPath('Desktop'), 'TabForge Studio.lnk'));$s.TargetPath='%~dp0Start_TabForge_Studio.vbs';$s.WorkingDirectory='%~dp0';$s.Save()"
    echo Desktop shortcut created!
    timeout /t 2 >nul
    goto MENU
)
if "%choice%"=="5" exit

goto MENU
