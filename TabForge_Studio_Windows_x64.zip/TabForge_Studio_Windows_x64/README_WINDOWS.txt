========================================================================
       TabForge Studio - Stratocaster Guitar Studio (Windows 64-bit)
========================================================================

Welcome to TabForge Studio for Windows (64-bit)!

This package contains everything needed to launch, run, setup, or compile
TabForge Studio on Windows 64-bit systems (Windows 10 / Windows 11).

------------------------------------------------------------------------
1. QUICK LAUNCH
------------------------------------------------------------------------
- Double-click "QUICK_START.bat" to open the TabForge Control Center.
- Or double-click "TabForge_Studio.bat" / "Start_TabForge_Studio.vbs".

------------------------------------------------------------------------
2. FIRST TIME SETUP (AUTOMATED 1-CLICK INSTALLER)
------------------------------------------------------------------------
If running TabForge Studio for the first time on a fresh Windows machine:
1. Double-click "Setup_Windows_x64.bat".
2. The script will automatically configure MSYS2 64-bit, GTK4, Libadwaita,
   GStreamer audio synthesizer engines, PyGObject, and Cairo graphics.
3. A Desktop Shortcut ("TabForge Studio") will be created automatically.

------------------------------------------------------------------------
3. BUILDING A STANDALONE .EXE FILE
------------------------------------------------------------------------
If you wish to compile TabForge Studio into a standalone executable:
1. Run "Build_EXE_Windows.bat".
2. The compiled application will be generated in `dist\TabForgeStudio_Win64\`.

------------------------------------------------------------------------
4. INCLUDED SOURCE FILES
------------------------------------------------------------------------
- main.py             : Application entry point & CSS provider setup
- window.py           : TabForge Studio UI, toolbar, audio engine & backup engine
- tab_canvas.py       : Interactive Cairo tab sheet rendering engine
- tab_engine.py       : Audio synthesis, wave generation & GStreamer player
- visual_picker.py    : Interactive Stratocaster fretboard picker & sound synthesis
- audio_recorder.py   : Audio interface recorder
- style.css           : Stratocaster Ultra-Premium Dark Studio Theme
- stratocaster.svg    : Vector graphics emblem

------------------------------------------------------------------------
Created for TabForge Studio - Windows 64-bit Release Package
========================================================================
