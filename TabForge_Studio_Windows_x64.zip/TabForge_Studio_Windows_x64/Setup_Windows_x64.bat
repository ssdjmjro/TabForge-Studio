@echo off
title TabForge Studio - Windows 64-bit Setup & Dependency Installer
color 0B
echo ===================================================================
echo   TabForge Studio - Automated Windows 64-bit Dependency Installer
echo ===================================================================
echo.
echo TabForge Studio relies on Python 3, GTK4, Libadwaita, PyGObject, GStreamer, and Cairo.
echo This installer will automatically configure MSYS2 64-bit and install all required libraries.
echo.
echo Press ANY KEY to begin setup...
pause >nul

:: Step 1: Check or Install MSYS2 64-bit
if not exist "C:\msys64\msys2_shell.cmd" (
    echo.
    echo [1/3] MSYS2 64-bit not found at C:\msys64. Downloading official installer...
    powershell -Command "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; Invoke-WebRequest -Uri 'https://github.com/msys2/msys2-installer/releases/download/2024-01-13/msys2-x86_64-20240113.exe' -OutFile '%TEMP%\msys2-installer.exe'"
    echo Installing MSYS2 64-bit to C:\msys64 ...
    "%TEMP%\msys2-installer.exe" --confirm-command --accept-messages --root C:\msys64
) else (
    echo [1/3] MSYS2 64-bit detected at C:\msys64.
)

:: Step 2: Install GTK4, Libadwaita, PyGObject, GStreamer, Cairo
echo.
echo [2/3] Installing GTK4, Libadwaita, GStreamer, PyGObject, Cairo via Pacman...
C:\msys64\usr\bin\bash.exe -lc "pacman -Sy --noconfirm"
C:\msys64\usr\bin\bash.exe -lc "pacman -S --noconfirm --needed mingw-w64-ucrt-x86_64-python mingw-w64-ucrt-x86_64-python-gobject mingw-w64-ucrt-x86_64-gtk4 mingw-w64-ucrt-x86_64-libadwaita mingw-w64-ucrt-x86_64-gstreamer mingw-w64-ucrt-x86_64-gst-plugins-base mingw-w64-ucrt-x86_64-gst-plugins-good mingw-w64-ucrt-x86_64-python-cairo"

:: Step 3: Desktop Shortcut
echo.
echo [3/3] Creating Desktop Shortcut for TabForge Studio...
powershell -Command "$s=(New-Object -COM WScript.Shell).CreateShortcut([System.IO.Path]::Combine([Environment]::GetFolderPath('Desktop'), 'TabForge Studio.lnk'));$s.TargetPath='%~dp0Start_TabForge_Studio.vbs';$s.WorkingDirectory='%~dp0';$s.Save()"

echo.
echo ===================================================================
echo   Setup Successfully Completed!
echo   You can now launch TabForge Studio using TabForge_Studio.bat
echo   or from the Desktop Shortcut!
echo ===================================================================
echo.
pause
